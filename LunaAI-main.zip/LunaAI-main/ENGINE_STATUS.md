# Estado del motor — Luna AI v4

## Fase 1 — objetivo actual

**TXT2IMG real local con Stable Diffusion 1.5 GGUF Q4_0.**

- Android arm64-v8a
- CPU backend como ruta garantizada
- 512×512 recomendado para la primera prueba
- batch 1
- 10–20 pasos
- seed reproducible
- positive + negative prompt
- modelo descargable y verificable por SHA-256
- sin créditos artificiales

## Dependencia nativa

`stable-diffusion.cpp` queda fijado al commit `d950627` para evitar que cambios futuros de su API rompan el build sin aviso. Su documentación indica que el proyecto está en desarrollo activo y que la API puede cambiar frecuentemente.

## Fase 2

Probar OpenCL para Adreno. La documentación actual de stable-diffusion.cpp indica que su backend OpenCL está orientado a GPUs Adreno y optimizado principalmente para Q4_0. No se activa todavía en producción hasta probarlo en el dispositivo.

## Fase 3+

img2img → inpainting → LoRA/continuidad → filtros de originalidad → vídeo.
