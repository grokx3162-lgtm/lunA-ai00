# Prompt maestro para reconstruir Luna AI

Crea una aplicación Android llamada Luna AI con estilo visual oscuro futurista/neón púrpura-azul/cian, paneles redondeados, navegación móvil y enfoque local-first.

Objetivo:
- Generar imágenes IA.
- Generar videos IA.
- Crear personajes sintéticos originales.
- Mantener continuidad de personajes mediante ID y seed.
- Director IA que convierte una idea en parámetros de escena.
- Galería e historial.
- Editor y exportación.
- Optimización del dispositivo.
- Motor local y motor online opcional.
- Sin cuotas artificiales de generaciones.

Dispositivo objetivo inicial:
- Redmi Note 13 4G.
- Snapdragon 685.
- Adreno 610.
- 8 GB RAM.
- almacenamiento libre aproximado 70+ GB.
- pantalla 120 Hz.

Regla de personajes:
Todos los personajes deben ser generados como identidades ficticias/sintéticas originales.
No pedir, promover ni diseñar una imitación deliberada de una persona real.
No recrear celebridades o personas existentes.
La app debe añadir una política de originalidad al prompt.
No afirmar unicidad matemática absoluta; usar lenguaje como "diseñado para ser original".

Pantallas:
1. Inicio
2. Crear imagen
3. Crear video
4. Personajes IA
5. Director IA
6. Galería
7. Resultado
8. Editor
9. Configuración
10. Motor/optimización

Crear:
- prompt principal
- negative prompt
- personaje
- estilo
- relación de aspecto
- duración para video
- cámara
- lente
- luz
- movimiento
- audio
- seed
- pasos
- resolución
- configuración avanzada

No-limits:
No implementar créditos, contador, paywall o límite artificial.
Aclarar que el hardware/modelo/proveedor puede tener límites físicos o comerciales.

Arquitectura:
- Kotlin
- Jetpack Compose
- GenerationEngine interface
- ModelManager
- local-first
- almacenamiento local
- backend online opcional

El APK no debe contener modelos grandes por defecto; los modelos se instalan/importan por separado.
