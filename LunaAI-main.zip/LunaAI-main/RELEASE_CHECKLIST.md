# Checklist de lanzamiento

- [x] UI nativa Compose
- [x] Imagen/Video modes
- [x] Original characters
- [x] Originality policy
- [x] Gallery/history flow
- [x] Device diagnostics copy
- [x] No artificial credit counter
- [x] Android-only cloud build workflow
- [ ] Real SD1.5 local inference backend
- [ ] Real image output persistence
- [ ] Real video backend
- [ ] Automated similarity/rejection filter
- [ ] Performance tuning on Snapdragon 685
