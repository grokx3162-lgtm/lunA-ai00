# Ejecutar Luna AI sin PC

## Ruta recomendada: GitHub Actions
1. Crea un repositorio privado en GitHub desde el móvil.
2. Sube todo el contenido de esta carpeta, respetando `.github/workflows/build-apk.yml`.
3. Abre la pestaña **Actions** del repositorio.
4. Ejecuta **Build Luna AI APK** con **Run workflow**.
5. Cuando termine, abre el artefacto **LunaAI-debug-apk** y descarga `app-debug.apk`.
6. En Android permite instalar la APK desde la fuente que uses para abrir el archivo y ejecuta Luna AI.

No necesitas instalar Android Studio en el teléfono para esta ruta.

## Requisitos de compilación
- JDK 17
- Gradle 9.6
- Android API 37
- Build Tools 36.0.0

La configuración coincide con la compatibilidad oficial de AGP 9.4.
