# Luna AI — arquitectura

## Capas

UI
→ AppState
→ GenerationEngine
→ Backend local / backend online
→ Model Manager
→ Media Storage

## GenerationEngine

La interfaz desacopla la UI del modelo:

```kotlin
interface GenerationEngine {
    val id: String
    val displayName: String
    val local: Boolean
    suspend fun generate(
        request: GenerationRequest,
        onProgress: (Int) -> Unit
    ): GenerationResult
}
```

### Motores previstos

1. `LocalOnnxEngine`
   - Modelos ONNX/Stable Diffusion compatibles.
   - CPU/GPU cuando el runtime lo permita.
   - Ideal para imágenes pequeñas/medianas.

2. `LocalMnnEngine`
   - Para paquetes MNN/Stable Diffusion optimizados para Snapdragon.
   - Requiere incluir los binarios y respetar sus licencias.

3. `MediaPipeImageEngine`
   - Alternativa de imagen si el dispositivo/modelo es compatible.

4. `RemoteEngine`
   - Adaptador opcional para un servidor/modelo que el usuario controle.
   - No debe ser obligatorio.

5. `VideoEngine`
   - Separado de imagen.
   - El Redmi Note 13 debe tratarse como dispositivo de capacidad limitada para video generativo.

## Originalidad

Cada personaje tiene:
- ID
- seed
- descripción
- perfil de identidad

El prompt final recibe una política de originalidad.

La app no debe aceptar una solicitud cuyo objetivo explícito sea copiar la identidad de una persona real.

## No-limit policy

No hay créditos internos.

No existe:

`if generations >= N then block`

La cola solo debe estar limitada por recursos reales del dispositivo.

## Persistencia futura

Usar Room/DataStore para:
- personajes
- proyectos
- configuraciones
- historial

Usar MediaStore / app-specific storage para:
- PNG/JPEG
- MP4
- miniaturas
- modelos

## Seguridad y privacidad

- No enviar archivos a internet por defecto.
- Mostrar claramente cuando se active un motor online.
- No incluir API keys en APK.
- Mantener modelos y proyectos locales cuando sea posible.
