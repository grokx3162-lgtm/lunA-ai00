# Luna AI — Fase 1: motor real local

Esta versión sustituye el DemoEngine por una integración nativa de stable-diffusion.cpp para Stable Diffusion 1.5.

## Objetivo del primer corte
- txt2img real y local.
- SD1.5 GGUF Q4_0.
- CPU Android como ruta conservadora.
- 512×512 / 512×768 / 640×480 / 768×432.
- batch 1.
- 16 pasos por defecto.
- seed persistente por personaje.
- negative prompt de originalidad.
- resultado guardado en almacenamiento privado de la aplicación.

## Modelo recomendado
`v1-5-pruned_Q4_0.gguf` de `kostakoff/stable-diffusion-v1-5-GGUF`.
La tarjeta del modelo indica 3.05 GB y licencia CreativeML OpenRAIL-M. La aplicación no incrusta los pesos: los descarga bajo acción explícita del usuario.

## Por qué CPU primero
El Redmi Note 13 con Snapdragon 685 no debe anunciar NPU V68 para este backend. Local Dream documenta NPU SD1.5 desde Hexagon V68; fuera de ese rango, CPU/GPU es la ruta compatible. El backend de esta fase usa CPU para minimizar problemas de enlace con OpenCL propietario.

## Siguiente paso
Después de validar txt2img real en el teléfono:
1. probar backend OpenCL en Adreno 610;
2. añadir cancelación y progreso nativo;
3. img2img;
4. inpainting/ControlNet;
5. continuidad avanzada de personaje;
6. vídeo ligero a partir de imagen;
7. vídeo generativo completo solo si el hardware/backend demuestra rendimiento suficiente.
