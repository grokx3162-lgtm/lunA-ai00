# Luna AI — Inicio real (v4)

Esta versión inicia la Fase 1 real: **Stable Diffusion 1.5 local en Android**, con `stable-diffusion.cpp` como motor nativo.

## Qué debes hacer desde Android

1. Descarga este ZIP.
2. Crea un repositorio nuevo en GitHub, por ejemplo `LunaAI`.
3. Sube **el contenido de esta carpeta `LunaAI_Android`**, no la carpeta contenedora.
4. En GitHub abre **Actions → Build Luna AI APK → Run workflow**.
5. Espera a que termine el build.
6. Abre la ejecución terminada → **Artifacts → LunaAI-debug-apk**.
7. Descarga el ZIP del artefacto y extrae `app-debug.apk`.
8. Instálalo en tu Redmi Note 13.
9. Dentro de Luna AI abre **Modelos → Descargar modelo SD1.5**.
10. La descarga ocupa aproximadamente 3.05 GB y se verifica con SHA-256 antes de activarse.

## Primera prueba

Después de instalar el modelo:

- Imagen
- 1:1
- 512×512
- 10–16 pasos
- batch 1
- un prompt sencillo, por ejemplo: `original fictional woman, cinematic portrait, studio lighting`

La primera generación puede ser lenta porque esta fase prioriza estabilidad y compatibilidad CPU. No cierres la aplicación durante la primera carga del modelo.

## Importante

- El APK **no contiene** el modelo de 3.05 GB.
- El modelo se descarga bajo demanda.
- La aplicación no cobra créditos ni impone cuotas artificiales.
- "Sin límite" significa sin contador de generaciones de la app; el límite real es batería, temperatura, RAM, almacenamiento y tiempo de cálculo.
- La Fase 1 usa CPU. OpenCL para Adreno queda como Fase 2 después de comprobar estabilidad en el Redmi Note 13.
