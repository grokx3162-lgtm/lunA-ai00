#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/third_party"
if [ ! -d "$ROOT/third_party/stable-diffusion.cpp/.git" ]; then
  git clone --depth 1 --recurse-submodules https://github.com/leejet/stable-diffusion.cpp.git "$ROOT/third_party/stable-diffusion.cpp"
else
  git -C "$ROOT/third_party/stable-diffusion.cpp" pull --ff-only
  git -C "$ROOT/third_party/stable-diffusion.cpp" submodule update --init --recursive
fi
echo "stable-diffusion.cpp listo en third_party/stable-diffusion.cpp"
