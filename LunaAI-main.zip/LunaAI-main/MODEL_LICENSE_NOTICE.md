# Modelo SD1.5

Luna AI no incluye pesos dentro del APK.

Modelo de referencia para esta integración:
`kostakoff/stable-diffusion-v1-5-GGUF / v1-5-pruned_Q4_0.gguf`

La tarjeta publicada del modelo declara que es una cuantización GGUF de Stable Diffusion v1.5 y que hereda CreativeML OpenRAIL-M. El usuario debe revisar y aceptar la licencia antes de usar el modelo.

Fuente: https://huggingface.co/kostakoff/stable-diffusion-v1-5-GGUF
