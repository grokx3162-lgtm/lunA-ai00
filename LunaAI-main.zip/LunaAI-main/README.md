# Luna AI — Android

Estudio Android de imágenes y videos IA, diseñado alrededor del Redmi Note 13 (Snapdragon 685, 8 GB RAM).

## Importante

Esta entrega contiene una **app Android funcional de interfaz, navegación, estado, personajes, política de originalidad, galería, cola/progreso y arquitectura de motor**.

El motor incluido es `DemoEngine`: simula una generación para comprobar el flujo, pero **no finge ser un modelo IA**. Para generación IA real hay que conectar un backend/modelo local compatible.

Esto es intencional: un APK pequeño no puede contener mágicamente un modelo de difusión/video de varios GB ni convertir el Snapdragon 685 en una GPU de gama alta.

## Características

- UI Luna AI estilo oscuro/neón.
- Imagen IA y Video IA como modos de creación.
- Director/flujo de creación preparado.
- Personajes sintéticos originales con seed/ID.
- Política de originalidad que añade instrucciones para evitar imitar personas reales.
- Galería e historial.
- Configuración local-first.
- Sin contador de créditos o cuotas dentro de la aplicación.
- Adaptación visual a móvil.
- Arquitectura `GenerationEngine` para conectar motores reales.

## "Sin límite" significa

La app **no impone un límite artificial de créditos o número de generaciones**.

En modo local, el límite real siempre será físico: RAM, almacenamiento, temperatura, batería, tiempo de inferencia y lo que el modelo pueda ejecutar en el dispositivo.

Si se conecta un proveedor online, cualquier límite de ese proveedor seguirá aplicando.

## Construir

1. Instala Android Studio reciente.
2. Abre esta carpeta como proyecto.
3. Deja que Gradle descargue el Android Gradle Plugin y las dependencias.
4. Usa JDK 17.
5. Conecta el Redmi Note 13 con depuración USB o usa un dispositivo Android ARM64 real.
6. Ejecuta `app`.

El proyecto usa Android Gradle Plugin 9.4.0, Gradle 9.6.0, Kotlin 2.4.10 y Compose BOM 2026.09.00.

## Conectar un motor real

Implementa `GenerationEngine` en:

`app/src/main/java/com/lunaai/app/`

y sustituye:

`val engine: GenerationEngine = DemoEngine()`

por tu motor local.

La interfaz ya entrega:

- prompt
- negative prompt
- personaje
- seed del personaje
- duración
- relación de aspecto
- estilo
- progreso

## Recomendación para el Redmi Note 13

El Snapdragon 685 incorpora Adreno 610 y Hexagon 686. Para modelos locales, prioriza modelos pequeños/optimizados y resoluciones moderadas. No asumas que la RAM virtual equivale a VRAM.

Para video IA local, espera una carga mucho mayor que para imágenes. Una arquitectura híbrida/local-first es más realista que intentar ejecutar un modelo de video grande directamente en este teléfono.

## Propiedad del proyecto

Este código de Luna AI es un punto de partida original para tu aplicación. Los motores/modelos externos que integres pueden tener licencias independientes: revisa la licencia de cada modelo/runtime antes de redistribuirlos.

## Fuentes técnicas consultadas

- Android Gradle Plugin 9.4.0 / Gradle 9.6.0: documentación oficial de Android.
- Compose BOM 2026.09.00: documentación oficial de Android.
- Especificaciones Redmi Note 13: Xiaomi México.
- Snapdragon 685: Qualcomm.


## v2 — entrega ejecutable por nube

Esta versión añade el workflow `.github/workflows/build-apk.yml` para compilar el APK desde GitHub Actions sin PC, además de documentación del estado real del motor y del procedimiento Android-only. El APK de esta entrega sigue usando `DemoEngine` hasta integrar los binarios/modelos de difusión locales; no se presenta un simulador como IA real.

## Fase 1 — motor de imagen local real

Esta entrega ya no depende del `DemoEngine` para imagen: incorpora `NativeSdEngine`, JNI y `stable-diffusion.cpp`. El proyecto descarga bajo acción del usuario el modelo SD1.5 GGUF Q4_0 y ejecuta txt2img localmente.

Perfil inicial para Redmi Note 13: CPU, batch 1, 16 pasos y 512px. Después de validar estabilidad se puede habilitar OpenCL/Adreno.

El modelo no se incluye dentro del APK por tamaño y licencia. Revisa `MODEL_LICENSE_NOTICE.md`.


## Build v4

La compilación CI usa stable-diffusion.cpp fijado a `d950627`, Android `arm64-v8a`, CPU primero y OpenMP/OpenCL desactivados para la primera prueba. El modelo Q4_0 se verifica con SHA-256 `24bcd54c1d1f0354a1cd19d07ad9a20771d43fde8318d505d71bcd84b078f20a`.
