#include <jni.h>
#include <android/log.h>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <string>
#include <vector>

#include "stable-diffusion.h"

#define LOG_TAG "LunaAI-Native"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static std::string jstring_to_string(JNIEnv* env, jstring value) {
    if (!value) return {};
    const char* chars = env->GetStringUTFChars(value, nullptr);
    if (!chars) return {};
    std::string result(chars);
    env->ReleaseStringUTFChars(value, chars);
    return result;
}

static void throw_runtime(JNIEnv* env, const std::string& message) {
    jclass cls = env->FindClass("java/lang/RuntimeException");
    if (cls) env->ThrowNew(cls, message.c_str());
}

static void progress_callback(int step, int steps, float /*time*/, void* data) {
    auto* env = reinterpret_cast<JNIEnv*>(data);
    (void)env;
    // Progress is intentionally not bridged per-step yet. The Kotlin layer uses
    // an indeterminate state because native callbacks must never retain JNIEnv.
    (void)step;
    (void)steps;
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_lunaai_app_NativeSdEngine_nativeGenerate(
    JNIEnv* env,
    jobject /*thiz*/,
    jstring modelPath,
    jstring prompt,
    jstring negativePrompt,
    jint width,
    jint height,
    jint steps,
    jlong seed,
    jint threads) {

    const std::string model = jstring_to_string(env, modelPath);
    const std::string positive = jstring_to_string(env, prompt);
    const std::string negative = jstring_to_string(env, negativePrompt);

    if (model.empty()) {
        throw_runtime(env, "No hay un modelo SD1.5 instalado. Descarga el modelo desde Modelos.");
        return nullptr;
    }
    if (positive.empty()) {
        throw_runtime(env, "El prompt principal está vacío.");
        return nullptr;
    }

    sd_ctx_params_t ctx_params;
    sd_ctx_params_init(&ctx_params);
    ctx_params.model_path = model.c_str();
    ctx_params.n_threads = threads > 0 ? threads : 4;
    ctx_params.enable_mmap = true;
    ctx_params.eager_load = false;
    ctx_params.backend = "cpu";
    ctx_params.params_backend = "cpu";

    sd_ctx_t* ctx = new_sd_ctx(&ctx_params);
    if (!ctx) {
        throw_runtime(env, "No se pudo cargar el modelo SD1.5. Revisa el archivo GGUF y el espacio disponible.");
        return nullptr;
    }

    sd_set_progress_callback(progress_callback, nullptr);

    sd_img_gen_params_t params;
    sd_img_gen_params_init(&params);
    params.prompt = positive.c_str();
    params.negative_prompt = negative.empty() ? nullptr : negative.c_str();
    params.width = width;
    params.height = height;
    params.sample_params.sample_steps = steps;
    params.sample_params.sample_method = EULER_A_SAMPLE_METHOD;
    params.sample_params.scheduler = DISCRETE_SCHEDULER;
    params.sample_params.guidance.txt_cfg = 7.0f;
    params.seed = seed;
    params.batch_count = 1;

    sd_image_t* images = nullptr;
    int imageCount = 0;
    const bool ok = generate_image(ctx, &params, &images, &imageCount);

    if (!ok || images == nullptr || imageCount < 1 || images[0].data == nullptr) {
        if (images) free_sd_images(images, imageCount);
        free_sd_ctx(ctx);
        throw_runtime(env, "El motor SD1.5 no pudo completar la generación. En este dispositivo se recomienda 512px, batch 1 y 10-20 pasos.");
        return nullptr;
    }

    const sd_image_t& image = images[0];
    if (image.channel != 3 && image.channel != 4) {
        free_sd_images(images, imageCount);
        free_sd_ctx(ctx);
        throw_runtime(env, "El motor devolvió un formato de imagen no compatible.");
        return nullptr;
    }

    // Return raw RGB/RGBA pixels plus a tiny header: [width:u32][height:u32][channels:u32][pixels...].
    const uint32_t w = image.width;
    const uint32_t h = image.height;
    const uint32_t c = image.channel;
    const size_t pixelBytes = static_cast<size_t>(w) * static_cast<size_t>(h) * static_cast<size_t>(c);
    const size_t total = 12 + pixelBytes;

    if (total > static_cast<size_t>(std::numeric_limits<jsize>::max())) {
        free_sd_images(images, imageCount);
        free_sd_ctx(ctx);
        throw_runtime(env, "La imagen es demasiado grande para transferirla al lado Android.");
        return nullptr;
    }

    jbyteArray result = env->NewByteArray(static_cast<jsize>(total));
    if (!result) {
        free_sd_images(images, imageCount);
        free_sd_ctx(ctx);
        throw_runtime(env, "Memoria insuficiente para devolver la imagen.");
        return nullptr;
    }

    std::vector<uint8_t> packed(total);
    std::memcpy(packed.data() + 0, &w, 4);
    std::memcpy(packed.data() + 4, &h, 4);
    std::memcpy(packed.data() + 8, &c, 4);
    std::memcpy(packed.data() + 12, image.data, pixelBytes);
    env->SetByteArrayRegion(result, 0, static_cast<jsize>(total), reinterpret_cast<const jbyte*>(packed.data()));

    free_sd_images(images, imageCount);
    free_sd_ctx(ctx);
    return result;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_lunaai_app_NativeSdEngine_nativeEngineInfo(JNIEnv* env, jobject /*thiz*/) {
    const char* info = sd_get_system_info();
    if (!info) info = "stable-diffusion.cpp / CPU";
    return env->NewStringUTF(info);
}
