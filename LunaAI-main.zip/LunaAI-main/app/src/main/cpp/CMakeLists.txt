cmake_minimum_required(VERSION 3.22.1)
project("luna_native")

if(NOT DEFINED SDCPP_DIR)
    set(SDCPP_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../../third_party/stable-diffusion.cpp")
endif()

if(NOT EXISTS "${SDCPP_DIR}/CMakeLists.txt")
    message(FATAL_ERROR "stable-diffusion.cpp not found at ${SDCPP_DIR}. Run scripts/setup_native_engine.sh first, or use the GitHub Actions workflow.")
endif()

# Android/Redmi-first configuration. CPU is the guaranteed backend for Phase 1.
set(SD_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(SD_BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(SD_BUILD_SHARED_GGML_LIB OFF CACHE BOOL "" FORCE)
set(SD_WEBP OFF CACHE BOOL "" FORCE)
set(SD_WEBM OFF CACHE BOOL "" FORCE)
set(SD_OPENCL OFF CACHE BOOL "" FORCE)
set(SD_VULKAN OFF CACHE BOOL "" FORCE)
set(SD_CUDA OFF CACHE BOOL "" FORCE)
set(SD_HIPBLAS OFF CACHE BOOL "" FORCE)
set(SD_METAL OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP OFF CACHE BOOL "" FORCE)

add_subdirectory("${SDCPP_DIR}" "${CMAKE_BINARY_DIR}/stable-diffusion.cpp")

add_library(luna_native SHARED luna_sd_jni.cpp)

target_include_directories(luna_native PRIVATE
    "${SDCPP_DIR}/include"
    "${SDCPP_DIR}/thirdparty"
)

target_link_libraries(luna_native
    stable-diffusion
    android
    log
)

target_compile_features(luna_native PRIVATE cxx_std_17)
target_compile_options(luna_native PRIVATE -fvisibility=hidden -O3)
