package com.lunaai.app

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

object LunaStorage {
    private lateinit var appContext: Context

    fun init(context: Context) {
        appContext = context.applicationContext
        generatedDir().mkdirs()
        modelsDir().mkdirs()
    }

    fun modelsDir(): File = File(appContext.filesDir, "models")
    fun generatedDir(): File = File(appContext.filesDir, "generated")
    fun sd15ModelFile(): File = File(modelsDir(), "v1-5-pruned_Q4_0.gguf")

    fun saveBitmap(bitmap: Bitmap): Uri {
        val file = File(generatedDir(), "LUNA-${System.currentTimeMillis()}.png")
        FileOutputStream(file).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        }
        return Uri.fromFile(file)
    }
}
