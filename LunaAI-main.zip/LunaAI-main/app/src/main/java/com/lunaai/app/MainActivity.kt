package com.lunaai.app

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

private val Bg = Color(0xFF050A18)
private val Card = Color(0xFF0B1530)
private val Card2 = Color(0xFF0E1D3D)
private val Purple = Color(0xFF9A6CFF)
private val Cyan = Color(0xFF35D7FF)
private val TextPrimary = Color(0xFFF4F2FF)
private val Muted = Color(0xFFA8B1CF)

data class CharacterProfile(
    val id: String,
    val name: String,
    val description: String,
    val seed: Long,
    val synthetic: Boolean = true
)

data class GenerationRequest(
    val kind: String,
    val prompt: String,
    val negativePrompt: String,
    val character: CharacterProfile?,
    val durationSeconds: Int = 5,
    val aspect: String = "9:16",
    val style: String = "Cinemático",
    val modelPath: String? = null,
    val steps: Int = 16,
    val seed: Long = System.currentTimeMillis()
)

data class GenerationResult(
    val id: String,
    val kind: String,
    val message: String,
    val uri: String? = null
)

interface GenerationEngine {
    val id: String
    val displayName: String
    val local: Boolean
    suspend fun generate(request: GenerationRequest, onProgress: (Int) -> Unit): GenerationResult
}

/*
 * UI/demo engine only.
 * It deliberately does NOT claim to perform AI inference.
 * Replace this adapter with a real local ONNX/MNN/MediaPipe/native backend.
 */
class DemoEngine : GenerationEngine {
    override val id = "demo"
    override val displayName = "Motor de demostración"
    override val local = true

    override suspend fun generate(
        request: GenerationRequest,
        onProgress: (Int) -> Unit
    ): GenerationResult {
        for (p in 0..100 step 10) {
            delay(90)
            onProgress(p)
        }
        return GenerationResult(
            id = "LUNA-${System.currentTimeMillis()}",
            kind = request.kind,
            message = "Resultado de demostración. Conecta un modelo local compatible para inferencia IA real."
        )
    }
}

object OriginalityPolicy {
    fun negativePrompt(user: String): String =
        listOf(
            user,
            "no imitar personas reales, no copiar celebridades, no recrear personas existentes, " +
                "no recrear personajes protegidos, identidad facial sintética original, " +
                "rasgos nuevos, personaje ficticio original"
        ).filter { it.isNotBlank() }.joinToString(", ")
}

class LunaAppState(context: Context) {
    var selectedTab by mutableStateOf(0)
    var createMode by mutableStateOf("Imagen")
    var prompt by mutableStateOf("")
    var negativePrompt by mutableStateOf("")
    var style by mutableStateOf("Cinemático")
    var aspect by mutableStateOf("9:16")
    var duration by mutableStateOf(5)
    var selectedCharacter by mutableStateOf<CharacterProfile?>(null)
    var isGenerating by mutableStateOf(false)
    var progress by mutableStateOf(0)
    var lastResult by mutableStateOf<GenerationResult?>(null)

    val characters = mutableStateListOf(
        CharacterProfile(
            "Luna-001",
            "Luna-001",
            "Personaje sintético original; rasgos generados desde cero.",
            458721
        ),
        CharacterProfile(
            "Astra-002",
            "Astra-002",
            "Identidad sintética original para continuidad.",
            882104
        )
    )

    val history = mutableStateListOf<GenerationResult>()
    val engine: GenerationEngine = NativeSdEngine()
    val modelFile: File = LunaStorage.sd15ModelFile()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        LunaStorage.init(this)
        setContent { LunaAI() }
    }
}

@Composable
fun LunaAI() {
    val context = LocalContext.current
    val state = remember { LunaAppState(context) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg,
            surface = Card,
            primary = Purple,
            secondary = Cyan,
            onBackground = TextPrimary,
            onSurface = TextPrimary
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Row(Modifier.fillMaxSize()) {
                NavigationRail(state)
                Box(Modifier.weight(1f)) {
                    when (state.selectedTab) {
                        0 -> HomeScreen(state)
                        1 -> CreateScreen(state)
                        2 -> CharactersScreen(state)
                        3 -> GalleryScreen(state)
                        4 -> SettingsScreen()
                    }
                }
            }
        }
    }
}

@Composable
fun NavigationRail(state: LunaAppState) {
    NavigationRail(
        containerColor = Color(0xFF071026),
        modifier = Modifier.width(86.dp)
    ) {
        Spacer(Modifier.height(18.dp))
        Text("◐", color = Purple, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))

        val items = listOf(
            Icons.Default.Home to "Inicio",
            Icons.Default.AddCircle to "Crear",
            Icons.Default.Person to "Personajes",
            Icons.Default.PhotoLibrary to "Galería",
            Icons.Default.Settings to "Ajustes"
        )

        items.forEachIndexed { index, pair ->
            NavigationRailItem(
                selected = state.selectedTab == index,
                onClick = { state.selectedTab = index },
                icon = { Icon(pair.first, null) },
                label = { Text(pair.second, fontSize = 9.sp) },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = TextPrimary,
                    selectedTextColor = TextPrimary,
                    indicatorColor = Purple.copy(alpha = .35f),
                    unselectedIconColor = Muted,
                    unselectedTextColor = Muted
                )
            )
        }
    }
}

@Composable
fun HomeScreen(state: LunaAppState) {
    LazyColumn(
        Modifier.fillMaxSize().padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Header("Luna AI", "Crea · Imagina · Genera") }

        item {
            HeroCard(
                "Tu estudio de imágenes y videos IA",
                "Personajes originales · Escenas únicas · Sin cuotas de generación"
            )
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FeatureCard(
                    "Imagen IA",
                    "Texto, personaje y escena",
                    Icons.Default.Image,
                    Modifier.weight(1f)
                ) {
                    state.selectedTab = 1
                    state.createMode = "Imagen"
                }

                FeatureCard(
                    "Video IA",
                    "Imagen → movimiento",
                    Icons.Default.PlayArrow,
                    Modifier.weight(1f)
                ) {
                    state.selectedTab = 1
                    state.createMode = "Video"
                }
            }
        }

        item { SectionTitle("Flujo recomendado") }
        item { WorkflowCard() }
        item { StatusCard() }
    }
}

@Composable
fun Header(title: String, subtitle: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(52.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(Purple, Cyan))),
            contentAlignment = Alignment.Center
        ) {
            Text("◐", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.width(12.dp))

        Column {
            Text(title, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun HeroCard(title: String, subtitle: String) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Card2),
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            Modifier.background(
                Brush.linearGradient(listOf(Color(0xFF111D4B), Color(0xFF32145D)))
            ).padding(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(title, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Muted)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Badge("∞ Sin límite")
                    Badge("100% original")
                    Badge("Local-first")
                }
            }
        }
    }
}

@Composable
fun Badge(text: String) {
    Surface(color = Purple.copy(alpha = .18f), shape = RoundedCornerShape(50)) {
        Text(
            text,
            Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            color = TextPrimary,
            fontSize = 11.sp
        )
    }
}

@Composable
fun FeatureCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Card)
    ) {
        Column(
            Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(30.dp))
            Text(title, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun WorkflowCard() {
    Card(
        colors = CardDefaults.cardColors(containerColor = Card),
        shape = RoundedCornerShape(20.dp)
    ) {
        Row(
            Modifier.fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            listOf(
                "Personaje original",
                "Imagen",
                "Animar",
                "Mejorar",
                "Exportar"
            ).forEachIndexed { i, s ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.width(95.dp)
                ) {
                    Box(
                        Modifier.size(46.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Purple.copy(alpha = .2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${i + 1}", color = TextPrimary, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        s,
                        fontSize = 10.sp,
                        color = Muted,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
                if (i < 4) Text("→", color = Cyan, fontSize = 20.sp)
            }
        }
    }
}

@Composable
fun StatusCard() {
    Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Motor y dispositivo", fontWeight = FontWeight.Bold)
            StatusLine("Snapdragon 685 / Adreno 610")
            StatusLine("8 GB RAM física")
            StatusLine("Almacenamiento libre: 70+ GB")
            StatusLine("Generaciones: sin cuotas artificiales")

            Text(
                "La app no impone créditos ni un contador de generaciones. La generación local real sigue limitada por la potencia, memoria, temperatura y modelos compatibles del teléfono.",
                color = Muted,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun StatusLine(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("✓", color = Cyan, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(8.dp))
        Text(text, fontSize = 12.sp)
    }
}

@Composable
fun CreateScreen(state: LunaAppState) {
    val scope = rememberCoroutineScope()
    var downloadingModel by remember { mutableStateOf(false) }
    var downloadText by remember { mutableStateOf("") }

    LazyColumn(
        Modifier.fillMaxSize().padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Header("Crear", "Imagen IA · Video IA") }

        item {
            ModelCard(
                installed = state.modelFile.exists() && state.modelFile.length() > 1_000_000_000L,
                downloading = downloadingModel,
                status = downloadText,
                onDownload = {
                    scope.launch {
                        downloadingModel = true
                        downloadText = "Preparando descarga…"
                        try {
                            ModelManager.downloadModel { d ->
                                scope.launch {
                                    val pct = if (d.total > 0) (d.downloaded * 100 / d.total).toInt() else 0
                                    downloadText = if (d.total > 0) "Descargando modelo: $pct%" else "Descargando modelo…"
                                }
                            }
                            downloadText = "Modelo SD1.5 listo · ${ModelManager.MODEL_SIZE_HINT}"
                        } catch (t: Throwable) {
                            downloadText = "Error: ${t.message ?: "descarga fallida"}"
                        } finally {
                            downloadingModel = false
                        }
                    }
                }
            )
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ModeButton("Imagen", state.createMode == "Imagen") {
                    state.createMode = "Imagen"
                }
                ModeButton("Video", state.createMode == "Video") {
                    state.createMode = "Video"
                }
            }
        }

        item {
            PromptBox(
                "Prompt principal",
                state.prompt,
                { state.prompt = it },
                "Describe lo que quieres crear..."
            )
        }

        item {
            PromptBox(
                "Negative prompt",
                state.negativePrompt,
                { state.negativePrompt = it },
                "Evitar personas reales, marcas, texto, deformidades..."
            )
        }

        item { SectionTitle("Personaje IA original") }
        item { CharacterPicker(state) }

        item { SectionTitle("Estilo") }
        item {
            ChipRow(
                listOf("Real", "Cinemático", "Natural", "Surreal", "Anime"),
                state.style
            ) { state.style = it }
        }

        item { SectionTitle("Relación de aspecto") }
        item {
            ChipRow(listOf("9:16", "16:9", "1:1", "4:3"), state.aspect) {
                state.aspect = it
            }
        }

        if (state.createMode == "Video") {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Duración: ${state.duration}s", color = Muted, fontSize = 12.sp)
                    Slider(
                        value = state.duration.toFloat(),
                        onValueChange = {
                            state.duration = it.toInt().coerceIn(1, 15)
                        },
                        valueRange = 1f..15f
                    )
                }
            }
        }

        item {
            Button(
                onClick = {
                    scope.launch {
                        state.isGenerating = true
                        state.progress = 0
                        try {
                            val request = GenerationRequest(
                                kind = state.createMode.lowercase(),
                                prompt = state.prompt,
                                negativePrompt =
                                    OriginalityPolicy.negativePrompt(state.negativePrompt),
                                character = state.selectedCharacter,
                                durationSeconds = state.duration,
                                aspect = state.aspect,
                                style = state.style,
                                modelPath = state.modelFile.takeIf { it.exists() }?.absolutePath,
                                steps = 16
                            )

                            val result = state.engine.generate(request) {
                                state.progress = it
                            }

                            state.lastResult = result
                            state.history.add(0, result)
                        } catch (t: Throwable) {
                            val error = GenerationResult(
                                id = "LUNA-ERROR-${System.currentTimeMillis()}",
                                kind = state.createMode.lowercase(),
                                message = "No se pudo generar: ${t.message ?: "error desconocido"}"
                            )
                            state.lastResult = error
                            state.history.add(0, error)
                        } finally {
                            state.isGenerating = false
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    if (state.isGenerating) {
                        "Generando ${state.progress}%"
                    } else {
                        "✦ Generar ${state.createMode.lowercase()}"
                    }
                )
            }
        }

        item { state.lastResult?.let { ResultCard(it) } }

        item {
            Text(
                "Motor real local: Stable Diffusion 1.5. En el Redmi Note 13 se inicia con CPU, 512px, batch 1 y 16 pasos para priorizar estabilidad. El modelo se guarda en almacenamiento privado de la app.",
                color = Muted,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun ModelCard(installed: Boolean, downloading: Boolean, status: String, onDownload: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Card2), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Motor local SD1.5", fontWeight = FontWeight.Bold)
            Text(
                if (installed) "✓ Modelo instalado · ${ModelManager.MODEL_NAME}" else "Modelo necesario para generar imágenes reales · ${ModelManager.MODEL_SIZE_HINT}",
                color = if (installed) Cyan else Muted,
                fontSize = 12.sp
            )
            Button(
                onClick = onDownload,
                enabled = !downloading && !installed,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(if (downloading) "Descargando…" else if (installed) "Modelo listo" else "Descargar modelo SD1.5")
            }
            if (status.isNotBlank()) Text(status, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun PromptBox(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String
) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp)

        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp),
            placeholder = { Text(placeholder, color = Muted) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Purple,
                unfocusedBorderColor = Color(0xFF24365E)
            )
        )
    }
}

@Composable
fun ModeButton(text: String, selected: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (selected) Purple else Card,
            contentColor = TextPrimary
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Text(text)
    }
}

@Composable
fun CharacterPicker(state: LunaAppState) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        state.characters.forEach { c ->
            Card(
                modifier = Modifier.fillMaxWidth()
                    .clickable { state.selectedCharacter = c },
                colors = CardDefaults.cardColors(
                    containerColor =
                        if (state.selectedCharacter?.id == c.id) {
                            Purple.copy(alpha = .22f)
                        } else {
                            Card
                        }
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(50.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                Brush.linearGradient(listOf(Purple, Cyan))
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("IA", fontWeight = FontWeight.Bold)
                    }

                    Spacer(Modifier.width(12.dp))

                    Column(Modifier.weight(1f)) {
                        Text(c.name, fontWeight = FontWeight.Bold)
                        Text(
                            "ID ${c.id} · Seed ${c.seed}",
                            color = Muted,
                            fontSize = 10.sp
                        )
                        Text(
                            "100% sintético / original",
                            color = Cyan,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ChipRow(items: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items.forEach {
            FilterChip(
                selected = selected == it,
                onClick = { onSelect(it) },
                label = { Text(it) }
            )
        }
    }
}

@Composable
fun ResultCard(result: GenerationResult) {
    Card(colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp)) {
        Column(
            Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Resultado ${result.kind}", fontWeight = FontWeight.Bold)
            Text(result.id, color = Cyan, fontSize = 11.sp)
            Text(result.message, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun CharactersScreen(state: LunaAppState) {
    LazyColumn(
        Modifier.fillMaxSize().padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Header("Personajes IA", "Identidades sintéticas y originales") }

        item {
            Button(
                onClick = {
                    val n = state.characters.size + 1
                    state.characters.add(
                        CharacterProfile(
                            id = "Luna-%03d".format(n),
                            name = "Luna-%03d".format(n),
                            description = "Nuevo personaje sintético.",
                            seed = (100000..999999).random().toLong()
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("+ Crear personaje original")
            }
        }

        items(state.characters) { c ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Card),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(
                    Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(c.name, fontWeight = FontWeight.Bold)
                    Text(c.description, color = Muted, fontSize = 12.sp)
                    Text("Seed: ${c.seed}", color = Cyan, fontSize = 11.sp)
                    Text(
                        "✓ Diseñado para identidad sintética; no se pretende recrear una persona real.",
                        color = Cyan,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
fun GalleryScreen(state: LunaAppState) {
    LazyColumn(
        Modifier.fillMaxSize().padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Header("Galería", "Tus imágenes, videos y proyectos") }

        if (state.history.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Card),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text(
                        "Todavía no hay generaciones. Crea la primera desde Crear.",
                        Modifier.padding(20.dp),
                        color = Muted
                    )
                }
            }
        } else {
            items(state.history) { ResultCard(it) }
        }
    }
}

@Composable
fun SettingsScreen() {
    LazyColumn(
        Modifier.fillMaxSize().padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Header("Configuración", "Motor · dispositivo · privacidad") }

        item {
            SettingCard(
                "Generación sin cuotas",
                "La aplicación no implementa créditos, anuncios obligatorios ni un contador de generaciones."
            )
        }

        item {
            SettingCard(
                "Motor local-first",
                "Tu Redmi Note 13 usa Snapdragon 685, Adreno 610 y 8 GB de RAM. El proyecto está preparado para seleccionar un backend local compatible."
            )
        }

        item {
            SettingCard(
                "Privacidad",
                "Los prompts, personajes y archivos deben permanecer en almacenamiento local salvo que tú actives un motor online."
            )
        }

        item {
            SettingCard(
                "Originalidad",
                "El generador añade una política de identidad sintética y evita pedir imitaciones de personas reales. No es una garantía matemática de unicidad."
            )
        }

        item {
            SettingCard(
                "Modelos",
                "Ruta prevista: Android/data/com.lunaai.app/files/models. Los modelos se descargan o importan por separado para mantener el APK pequeño."
            )
        }
    }
}

@Composable
fun SettingCard(title: String, body: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Card),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            Modifier.padding(17.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Text(title, fontWeight = FontWeight.Bold)
            Text(body, color = Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
}
