package com.lunaai.app

import android.graphics.Bitmap
import android.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class NativeSdEngine : GenerationEngine {
    override val id: String = "sd15-native"
    override val displayName: String = "Stable Diffusion 1.5 local"
    override val local: Boolean = true

    companion object {
        init {
            try {
                System.loadLibrary("luna_native")
            } catch (_: UnsatisfiedLinkError) {
                // The UI can still open when the native library is not included yet.
            }
        }

        @JvmStatic
        private external fun nativeGenerate(
            modelPath: String,
            prompt: String,
            negativePrompt: String,
            width: Int,
            height: Int,
            steps: Int,
            seed: Long,
            threads: Int
        ): ByteArray?

        @JvmStatic
        private external fun nativeEngineInfo(): String

        fun isAvailable(): Boolean = try {
            nativeEngineInfo()
            true
        } catch (_: Throwable) {
            false
        }
    }

    override suspend fun generate(
        request: GenerationRequest,
        onProgress: (Int) -> Unit
    ): GenerationResult = withContext(Dispatchers.Default) {
        if (request.kind != "imagen") {
            return@withContext GenerationResult(
                id = "LUNA-${System.currentTimeMillis()}",
                kind = request.kind,
                message = "El motor local real de esta fase genera imágenes. El módulo de vídeo se integra después sobre esta base."
            )
        }

        val modelPath = request.modelPath
            ?: throw IllegalStateException("No hay un modelo SD1.5 seleccionado.")

        val (width, height) = aspectSize(request.aspect)
        val steps = request.steps.coerceIn(10, 20)
        val seed = request.character?.seed ?: request.seed
        val threads = (Runtime.getRuntime().availableProcessors() - 1).coerceIn(2, 6)

        onProgress(1)
        val packed = nativeGenerate(
            modelPath,
            request.prompt,
            request.negativePrompt,
            width,
            height,
            steps,
            seed,
            threads
        ) ?: throw IllegalStateException("El motor local no devolvió una imagen.")
        onProgress(95)

        val bitmap = unpackBitmap(packed)
        val uri = LunaStorage.saveBitmap(bitmap)
        bitmap.recycle()
        onProgress(100)

        GenerationResult(
            id = "LUNA-${System.currentTimeMillis()}",
            kind = "imagen",
            message = "Generación local real SD1.5 · ${width}×${height} · ${steps} pasos · seed $seed",
            uri = uri.toString()
        )
    }

    private fun aspectSize(aspect: String): Pair<Int, Int> = when (aspect) {
        "16:9" -> 768 to 432
        "1:1" -> 512 to 512
        "4:3" -> 640 to 480
        else -> 512 to 768
    }

    private fun unpackBitmap(data: ByteArray): Bitmap {
        require(data.size >= 12) { "Respuesta nativa inválida." }
        val width = readInt(data, 0)
        val height = readInt(data, 4)
        val channels = readInt(data, 8)
        require(channels == 3 || channels == 4) { "Canales no compatibles: $channels" }
        val expected = 12 + width * height * channels
        require(data.size >= expected) { "Datos de imagen incompletos." }

        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val pixels = IntArray(width * height)
        var src = 12
        for (i in pixels.indices) {
            val r = data[src++].toInt() and 0xff
            val g = data[src++].toInt() and 0xff
            val b = data[src++].toInt() and 0xff
            val a = if (channels == 4) data[src++].toInt() and 0xff else 255
            pixels[i] = Color.argb(a, r, g, b)
        }
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
        return bitmap
    }

    private fun readInt(data: ByteArray, offset: Int): Int =
        (data[offset].toInt() and 0xff) or
            ((data[offset + 1].toInt() and 0xff) shl 8) or
            ((data[offset + 2].toInt() and 0xff) shl 16) or
            ((data[offset + 3].toInt() and 0xff) shl 24)
}
