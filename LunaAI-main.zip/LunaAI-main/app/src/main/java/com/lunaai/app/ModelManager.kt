package com.lunaai.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

object ModelManager {
    const val MODEL_URL = "https://huggingface.co/kostakoff/stable-diffusion-v1-5-GGUF/resolve/main/v1-5-pruned_Q4_0.gguf?download=true"
    const val MODEL_NAME = "SD 1.5 Q4_0"
    const val MODEL_SIZE_HINT = "≈ 3.05 GB"
    const val MODEL_SIZE_BYTES = 3_051_366_272L
    const val MODEL_SHA256 = "24bcd54c1d1f0354a1cd19d07ad9a20771d43fde8318d505d71bcd84b078f20a"

    data class DownloadState(val downloaded: Long, val total: Long, val running: Boolean, val error: String? = null)

    suspend fun downloadModel(onProgress: (DownloadState) -> Unit) = withContext(Dispatchers.IO) {
        val target = LunaStorage.sd15ModelFile()
        val part = File(target.parentFile, target.name + ".part")
        var existing = if (part.exists()) part.length() else 0L

        try {
            val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
                connectTimeout = 30_000
                readTimeout = 60_000
                instanceFollowRedirects = true
                if (existing > 0) setRequestProperty("Range", "bytes=$existing-")
            }
            connection.connect()

            val response = connection.responseCode
            val total = if (response == HttpURLConnection.HTTP_PARTIAL) {
                existing + connection.contentLengthLong.coerceAtLeast(0L)
            } else {
                existing = 0L
                connection.contentLengthLong.coerceAtLeast(0L)
            }

            if (response != HttpURLConnection.HTTP_OK && response != HttpURLConnection.HTTP_PARTIAL) {
                throw IllegalStateException("Servidor devolvió HTTP $response")
            }

            RandomAccessFile(part, "rw").use { file ->
                file.seek(existing)
                connection.inputStream.use { input ->
                    val buffer = ByteArray(1024 * 1024)
                    var done = existing
                    onProgress(DownloadState(done, total, true))
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        file.write(buffer, 0, read)
                        done += read
                        onProgress(DownloadState(done, total, true))
                    }
                }
            }
            connection.disconnect()

            val expected = if (total > 0) total else MODEL_SIZE_BYTES
            if (part.length() != expected) {
                throw IllegalStateException("Descarga incompleta: ${part.length()} / $expected bytes")
            }

            onProgress(DownloadState(part.length(), expected, true))
            val digest = sha256(part)
            if (!digest.equals(MODEL_SHA256, ignoreCase = true)) {
                part.delete()
                throw IllegalStateException("SHA-256 del modelo no coincide. La descarga se descartó por seguridad.")
            }

            if (target.exists()) target.delete()
            if (!part.renameTo(target)) throw IllegalStateException("No se pudo finalizar el archivo del modelo.")
            onProgress(DownloadState(target.length(), target.length(), false))
        } catch (t: Throwable) {
            onProgress(DownloadState(part.length(), 0, false, t.message ?: "Error de descarga"))
            throw t
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(1024 * 1024)
            while (true) {
                val n = input.read(buffer)
                if (n <= 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
